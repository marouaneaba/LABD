

CMP	Le code du serveur compile correctement avec Maven
DOC	Le code du serveur est document� (Readme.md, Javadoc)
TST	Le code du serveur est proporement test� (tests unitaires sous JUnit)
COO	Le code du serveur est con�u en suivant les principes de conception objet

GETB	Je peux t�l�charger un fichier binaire (image)
GETR	Je peux t�l�charger un r�pertoire complet
PUTB	Je peux mettre en ligne un fichier binaire (image)
PUTR	Je peux mettre en ligne un r�pertoire complet
RENF	Je peux renommer un fichier distant
MKD	Je peux cr�er un r�pertoire distant
REND	Je peux renommer un r�pertoire distant
RMD	Je peux supprimer un r�pertoire distant

HOME	Je peux configurer le r�pertoire racine du serveur FTP