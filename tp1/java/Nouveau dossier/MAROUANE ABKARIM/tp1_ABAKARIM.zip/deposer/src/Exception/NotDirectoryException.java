/*
   Marouane ABAKARIM
 */
package Exception;

/**
 *
 * @author amk
 */
public class NotDirectoryException extends Exception{
    
    public NotDirectoryException(){
        System.out.println("Not Existe this Directory ");
    }
}
