/*
   Marouane ABAKARIM
 */
package Exception;

/**
 *
 * @author amk
 */
public class NotExistCommandException extends Exception{
    
}
