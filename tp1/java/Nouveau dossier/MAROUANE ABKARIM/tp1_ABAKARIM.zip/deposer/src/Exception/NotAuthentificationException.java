/*
   Marouane ABAKARIM
 */
package Exception;

/**
 *
 * @author amk
 */
public class NotAuthentificationException extends Exception{
    
    
    public NotAuthentificationException()
    {
        System.out.println("Please entry the Good Command.\r\n");
    }
}
