

Nom: marouane Abakarim , veuillez trouver le Rapport en piece-joint "Rapport_car.docx".


la conception de notre sereveur et fait par le logiciel netbean �cout par d�faut sur le port 1069.

por configurer le repertoire de serveur aussi le numero de port on le configurer dans la class difinition de package Admin.

apr�s que le client a r�ussi de s'authentifi� ( une v�rification et fait par l'appel de la class UserClass de packege Admin )
le client peux ex�cuter plusieur commandes :	QUIT,LS,PUT,RETR,STOR,CWD,PWD,RENAME,MKDIR,RMDIR,

	
Un R�sumer de tout on a fait sur le Document "Rapport_car.docx".