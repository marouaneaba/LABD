/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Exception;

/**
 *
 * @author amk
 */
public class NotAuthentificationException extends Exception{
    
    
    public NotAuthentificationException()
    {
        System.out.println("Please entry the Good Command.\r\n");
    }
}
