﻿Binome : marouane abakarim
	ayoub mamane


Exercice 1 :
 championnat.xsd

Exercice 2: 
	examen-1.xsd et examen-2.xsd

Execice 3:
a.xml et b.xml

Exercice 4:

//*  : vas accéeder a tout les balise de ficheier personnes.xml

//nom  :
et associé à un espace de nom , pour l'afficher il faut declarer son name space

-pour afficher la balise nom ,faut faire la Xpath : 
declare namespace x="http://www.fil.univ-lille1.fr/labd";
//x:nom


3.
declare namespace x="http://www.fil.univ-lille1.fr/labd";
//x:personne[./x:sexe/text() = "M"]/x:naissance/x:date


Exercice 5:
	exercice5.xsd et Voir individu.xsd, insee-commun.xsd