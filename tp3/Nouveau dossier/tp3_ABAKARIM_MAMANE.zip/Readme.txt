Binom :	Marouane Abakarim
	Ayoub Mamane

* concernant exo 4 : on a pas compris la question, est-ce-qu'il faut modifier la structure de fichier championnat.xml est cr�� � la suite un sh�ma adapt�, 
	ou bien cr�er un sh�ma pour le fichier championnat par d�faut et d�tecter si il correspond au crit�re donn�e (38 j, 10 rencontre par j .... ) 
	car il manque 17 j et 1 rencontre, du coup il y a 2 version "ex4.xml" et "ex4.xsd" correspand � la premi�re th�orie, et championnat xml et xsd 
	� la 2 eme.

	Exo 4: 1er Version : ex4.xsd et exo4.xml
	       2eme Version : championnat.xsd et championnat.xml