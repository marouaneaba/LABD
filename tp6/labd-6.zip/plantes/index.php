<?php header("Content-type: text/xml"); ?>
<?xml-stylesheet type="text/xsl" href="index.xsl"?>
<?php echo "<page/>";?>
